from utils import get_logger
from crawler.frontier import Frontier
from crawler.worker import Worker
import threading
import scraper
from nltk.corpus import stopwords

class Crawler(object):
    def __init__(self, config, restart, frontier_factory=Frontier, worker_factory=Worker):
        print("crawler")
        self.config = config
        self.logger = get_logger("CRAWLER")
        self.frontier = frontier_factory(config, restart)
        self.workers = list()
        self.worker_factory = worker_factory
        self.ICSLock=threading.Lock()
        self.CSLock=threading.Lock()
        self.InformaticsLock=threading.Lock()
        self.StatLock=threading.Lock()
        self.TodayLock=threading.Lock()
        self.lockDict={"ics":self.ICSLock,"cs":self.CSLock,"informatics":self.InformaticsLock,"stat":self.StatLock,"today":self.TodayLock}
        self.frontierLock=threading.Lock()
        self.stopwordsnltk=set(stopwords.words('english'))

    def start_async(self):
        self.workers = [
            self.worker_factory(worker_id, self.config, self.frontier,self.lockDict, self.frontierLock,self.stopwordsnltk)
            for worker_id in range(self.config.threads_count)]
        for worker in self.workers:
            worker.start()

    def start(self):
        self.start_async()
        self.join()

        scraper.subDomainsICS()
        scraper.commonTokens()
        scraper.pageTokensWrite()
        print('Longest Page: ',scraper.longestPage)
        print('Longest Page length: ',scraper.tokenOfLongestPage)

    def join(self):
        for worker in self.workers:
            worker.join()
