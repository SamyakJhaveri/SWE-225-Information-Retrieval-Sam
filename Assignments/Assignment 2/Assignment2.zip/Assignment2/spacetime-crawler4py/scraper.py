import re
from re import search
from urllib.parse import urlparse, urldefrag
from bs4 import BeautifulSoup
from urllib import request
from nltk import *
from urllib.request import Request, urlopen
from nltk.corpus import stopwords
import threading

domains = set(["ics.uci.edu", "cs.uci.edu", "informatics.uci.edu", "stat.uci.edu", "today.uci.edu"])
all_links_found = set()
longestPage = ''
tokenOfLongestPage = 0
tokenDict = dict()
pageTokensDict=dict()


#Takes url from frontier, check for valid response, if yes: 
# 1. Returns list of URLs to be added to frontier from input URL
# 2. Tokenizes the URL and store in global dictionary of URL:tokencount
# 3. Adds the URL to global set of all the links found and writes to a file
# 4. If tokens found in a page are less than 50, ignore the page
# 5. Updates the longest page and highest tokens till now

def scraper(url, resp,lock,stopwordsnltk):

    global tokenOfLongestPage
    global longestPage
    links = []
    #Checks if the response status of URL is valid
    if resp.status in (200, 201, 202):

        #Tokenizes the URL page content
        tokenList=tokenize(resp,stopwordsnltk)
        
        #Checks for low information value
        if len(tokenList)<50:
            return list()
        
        else:
            #Lock applied for shared variables
            lock.acquire()

            x=urldefrag(url).url

            #Adding tokens to {URL:no.of tokens} dictionary
            pageTokensDict[url]=len(tokenList)

            if x not in all_links_found:
                all_links_found.add(x)
                #Appends the URL to text file
                with open("unique_urls.txt", "a+") as file_object:
                    file_object.seek(0)
                    data = file_object.read(100)
                    if len(data) > 0 :
                        file_object.write("\n")
                    file_object.write(x)
                file_object.close()

            #Updates the global token dictionary
            for token in tokenList:
                token=token.lower()
                if token in tokenDict:
                    tokenDict[token] += 1
                else:
                    tokenDict[token] = 1

            #Checks if the current page has tokens>max tokens till now
            if len(tokenList) > tokenOfLongestPage:
                tokenOfLongestPage = len(tokenList)
                longestPage = url

            #Releasing lock of shared variables
            lock.release()
            
            links=[]
            #Extracting links present in the content of current URL
            links = extract_next_links(resp)

            #Checks if the extracted links are valid and remove their fragment part
            valid_links = []
            if links:
                for link in links:
                    if is_valid(link):
                        valid_links.append(link.partition('#')[0])
            
            #Return valid urls from input URL
            return valid_links

#Writes 50 most common tokens in the entire set of pages to a file
def commonTokens():

    #Sorts the token dictionary in decreasing order of token count
    dictTokens={k:v for k,v in sorted(tokenDict.items(),key=lambda x:x[1],reverse=True)}

    #Writes to the file
    with open("common_tokens.txt", "a+") as file_object:
        counter = 1
        for key, value in dictTokens.items():
            if counter <= 50:
                file_object.seek(0)
                data = file_object.read(100)
                if len(data) > 0 :
                    file_object.write("\n")
                file_object.write(key+ " --> "+str(value))
                counter += 1
    file_object.close()

#Writes subdomains and their counts in the 'ics.uci.edu' domain to a file
def subDomainsICS():
   
    ICSDomainDict = dict()
    ICSdomain = "ics.uci.edu"
    for link in all_links_found:
        parsed = urlparse(link)
        netloc = parsed.netloc
        if netloc.startswith("www."):
            netloc = netloc.strip("www.")
        netloc=netloc.lower()
        if ICSdomain == netloc or '.'+ICSdomain in netloc:
            if netloc not in ICSDomainDict:
                ICSDomainDict[netloc] = 1
            else:
                ICSDomainDict[netloc] += 1
    #Sorts the subdomain dictionary in ascending order of key
    sortedDomainDict = {k:v for k,v in sorted(ICSDomainDict.items(),key=lambda x:x[0])}

    with open("ICSsubDomain.txt", "a+") as file_object:
        for key in sortedDomainDict:
            file_object.write(key + ", " + str(sortedDomainDict[key]))
            file_object.write("\n")
    file_object.close()

#Writes Token count of all the URLs in a file
def pageTokensWrite():
    sortedDict = {k:v for k,v in sorted(pageTokensDict.items(),key=lambda x:x[1],reverse=True)}
    with open("PageTokenCount.txt", "a+") as file_object:
        for key in sortedDict:
            file_object.write(key + ", " + str(pageTokensDict[key]))
            file_object.write("\n")
    file_object.close()

#Returns the extracted the links from a URL
def extract_next_links(resp):

    html = resp.raw_response.content
    soup = BeautifulSoup(html, 'html.parser')
    urls = soup.find_all("a")
    links = []
    for link in urls:
        links.append(link.get('href'))

    if links:
        return links
    else:
        return list()
   
#Checks if a url is valid: Checks for valid scheme, netloc, path and query
#1. Removes comments, filters, share, calenders and dates as low/no information value
#2. Removes files with extensions provided below
def is_valid(url):
    
    try:
        url_defrag = urldefrag(url).url
        parsed = urlparse(url_defrag)

        scheme = parsed.scheme
        netloc = parsed.netloc
        path = parsed.path
        query = parsed.query

        if scheme not in set(["http", "https"]):
            return False

        if netloc.startswith("www."):
            netloc = netloc.strip("www.")
        
        if netloc not in domains:
            if not(netloc.endswith('.ics.uci.edu') or netloc.endswith('.cs.uci.edu') or netloc.endswith('.informatics.uci.edu') or netloc.endswith('.stat.uci.edu')):
                return False
        
        if query.startswith('replytocom') or query.startswith('share') or query.startswith('action') or query.startswith('filter') or query.startswith('ical') :
            return False
        
        if netloc=='today.uci.edu' and not (path.startswith('department/information_computer_sciences')):
            return False
        
        if '/pdf/' in path or '/publications/' in path:
            return False

        if re.search("\d{4}-\d{2}(-\d{2})?", url):
            return False

        return not re.match(
            r".*\.(css|js|bmp|gif|jpe?g|ico"
            + r"|png|tiff?|mid|mp2|mp3|mp4"
            + r"|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf|txt"
            + r"|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names|ppsx"
            + r"|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso"
            + r"|epub|dll|cnf|tgz|sha1"
            + r"|thmx|mso|arff|rtf|jar|csv"
            + r"|rm|smil|wmv|swf|wma|zip|rar|gz)$", parsed.path.lower())
            
    except TypeError:
        print ("TypeError for ", parsed)
        raise

#Tokenizes the URL content using NLTK and returns the token list
def tokenize(resp,stopwordsnltk):
        
        # getthe raw html scripting of the url
        html = resp.raw_response.content
        # Get the Text from the HTML
        raw = BeautifulSoup(html, "html.parser").get_text()
        # Get All the Tokens, inclluding punctuation and stopwords
        all_tokens = word_tokenize(raw)
        # Get only the alphanumeric words and get rid of all the tokens
        # that are stopword, punctuation marks and symbols
        only_words = [w for w in all_tokens if w.isalnum() and w not in stopwordsnltk and len(w) > 3]
        return only_words
        